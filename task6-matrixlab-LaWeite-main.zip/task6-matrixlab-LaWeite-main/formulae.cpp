#include "formulae.h"

namespace global {
	std::map<std::string, Matrix> Workspace;
}
